# Copyright (c) 2024 Microsoft Corporation.
# Licensed under the MIT License

"""The Indexing Engine text extract claims strategies graph intelligence package root."""

from .run_gi_extract_claims import run

__all__ = ["run"]
