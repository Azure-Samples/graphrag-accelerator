# Copyright (c) 2024 Microsoft Corporation.
# Licensed under the MIT License

"""The LocalSearch package."""
